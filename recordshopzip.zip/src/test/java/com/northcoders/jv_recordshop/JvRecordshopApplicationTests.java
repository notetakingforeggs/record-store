package com.northcoders.jv_recordshop;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JvRecordshopApplicationTests {

	@Test
	@DisplayName("Get all records - ret")
	void contextLoads() {
	}

}
