package com.northcoders.jv_recordshop.view;

public class ASCIIArt {
    public void printRecordShop() {
        String recordShop = """                    
                     (                              (                     \s
                     )\\ )                     (     )\\ )    )             \s
                    (()/\\(   (           (     )\\ ) (()/( ( /(             \s
                     /(_)) ))\\  (   (   )(   (()/(  /(_)))\\())  (   `  )  \s
                    (_))  /((_) )\\  )\\ (()\\   ((_))(_)) ((_)\\   )\\  /(/(  \s
                    | _ \\(_))  ((_)((_) ((_)  _| | / __|| |(_) ((_)((_)_\\ \s
                    |   // -_)/ _|/ _ \\| '_|/ _` | \\__ \\| ' \\ / _ \\| '_ \\)\s
                    |_|_\\\\___|\\__|\\___/|_|  \\__,_| |___/|_||_|\\___/| .__/ \s
                                                                   |_|    \s      
                """;
        System.out.println(recordShop);
    }
}
