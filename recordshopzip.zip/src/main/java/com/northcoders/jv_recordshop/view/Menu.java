package com.northcoders.jv_recordshop.view;

public class Menu {
    public void menu(){
        System.out.println("Please choose from the following options");
        System.out.println("1: view all records");
        System.out.println("2: search records by...");
        System.out.println("3: remove record by ID");
        System.out.println("4: update record");
        System.out.println("5: add new record to the catalogue");
        System.out.println("6: quit");
    }
}
