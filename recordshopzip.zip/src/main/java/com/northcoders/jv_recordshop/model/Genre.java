package com.northcoders.jv_recordshop.model;


public enum Genre {
    HIPHOP,
    ROCK,
    CLASSICAL,
    JAZZ,
    AMBIENT,
    EXPERIMENTAL,
    ELECTRONIC,
    POP
}

